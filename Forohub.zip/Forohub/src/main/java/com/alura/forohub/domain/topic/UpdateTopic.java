package com.alura.forohub.domain.topic;

public record UpdateTopic(
        String title,
        String message
) {
}
