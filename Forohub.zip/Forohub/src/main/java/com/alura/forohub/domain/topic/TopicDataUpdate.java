package com.alura.forohub.domain.topic;

public record TopicDataUpdate(
        Long id,
        String title,
        String message
) {
}
