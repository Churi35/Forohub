package com.alura.forohub.domain.topic;

public enum TopicStatus {
    CREADO,
    MODIFICADO,
    ELIMINADO
}
